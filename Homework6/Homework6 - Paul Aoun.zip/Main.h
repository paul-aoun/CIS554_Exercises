#pragma once

void printMonthlyInterestBalances(double& monthlyInterest1, SavingsAccount& saver1, double& monthlyInterest2, SavingsAccount& saver2);

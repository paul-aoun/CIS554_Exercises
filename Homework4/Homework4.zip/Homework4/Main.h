#pragma once

void inputCorrectAnswer(bool& continueLoopingInner, ComputerAssistedInstruction& CAI, int num1, int num2, int& answer, bool& continueLooping, int result);

void checkRate(ComputerAssistedInstruction& CAI);
